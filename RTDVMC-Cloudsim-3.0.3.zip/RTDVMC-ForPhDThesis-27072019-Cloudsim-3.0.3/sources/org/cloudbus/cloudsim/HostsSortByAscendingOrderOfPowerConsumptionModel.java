package org.cloudbus.cloudsim;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHostUtilizationHistory;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G4Xeon3040;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G5Xeon3075;
import org.cloudbus.cloudsim.power.PowerHost;

public class HostsSortByAscendingOrderOfPowerConsumptionModel {
	/**
 	 * Sort hosts in ascending order based on hosts' enery consumption rate or power efficiency.
 	 * 
 	 * @param hostList the host list
 	 */
 	public static <T extends PowerHost> void sortHostsByAscendingOrderOfPowerConsumptionModel(List<T> hostList) 
 	{
 		Collections.sort(hostList, new Comparator<T>() {@Override
 			public int compare(T a, T b) throws ClassCastException 
			{
				//double currentTime = CloudSim.clock();
				Double aPowerConsumptionAtIdle = null;
				Double bPowerConsumptionAtIdle = null;
				if( a.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G4Xeon3040)
				{
					aPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G4Xeon3040.power[0];
				}
				else if(a.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G5Xeon3075)
				{
					aPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G5Xeon3075.power[0];
				}
				
				if( b.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G4Xeon3040)
				{
					bPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G4Xeon3040.power[0];
				}
				else if(b.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G5Xeon3075)
				{
					bPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G5Xeon3075.power[0];
				}
				//Double aPowerConsumption = ;
				return aPowerConsumptionAtIdle.compareTo(bPowerConsumptionAtIdle);
			}
 		});
 	}
	

}
